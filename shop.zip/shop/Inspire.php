<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Footwear</title>
	<meta name="viewport" content="1170">
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<!---Navigation----->
<section id="nav-bar">
	<nav class="navbar navbar-expand-lg navbar-light ">
  <div class="container-fluid">
    <a class="navbar-brand" href="index (20.php">
			<img src="http://ipic.su/img/img7/fs/75CE17C7-16A0-4939-9065-498C45DD493C.1614173565.jpg">
	  </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
         <li class="nav-item"><a class="nav-link" href="index (2).php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="modellingcourse.php">Modelling course</a></li>
        <li class="nav-item"><a class="nav-link" href="giftcard.php">Gift-Cards</a></li>
        <li class="nav-item"><a class="nav-link" href="cart_main.php">basket</a></li>
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Clothes</a>
		     <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="Dresses.php">Dress</a></li>
            <li><a class="dropdown-item" href="Footwear.php">Footwear</a></li>
            <li><a class="dropdown-item" href="Accessories.php">Accessories</a></li>
         </ul>
        </li>
				<li class="nav-item"><a class="nav-link " href="Inspire.php">Inspire</a></li>
        <li class="nav-item"><a class="nav-link" href="Contact.php">Contact</a></li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
  </nav>
</section>

 <!-- Video -->
<section>
	 	<video id="slider" autoplay loop muted>
	 		<source src="videoss/vrt.mp4" type='video/mp4; codecs="avc1.42E01E, mp4a.40.2"'>
	 	</video>
	 	
	 </section>
<!-- Video -->


                <!-- lOOKBOOK-  -->
<section id= "testimonials">
  <div class="container">
    <h1> LOOKBOOK</h1>
    <p class="text-center">A festive dress is carefully selected, and we open a precious jewelry box to try on them for a long time in front of the mirror.</p>
    <div class="row">
<div class="col-md-4 text-center">
  <div class="profile">
    <img src="http://ipic.su/img/img7/fs/FDA238A3-861D-475F-8234-5EBFC5B661F4.1614343776.jpg" class="user" >
    <blockquote>
      In our New Year story, we wanted to tell first of all about the family warmth and magic of a festive night. We created this atmosphere with the help of light, color and textures that we borrowed from canvases in the Rococo style, with their grace, intimacy, exquisite decorativeness and complex muted shades. The New Year gives us soulful and dear moments of meeting with loved ones. Their smiles and hugs that we missed so much.
    </blockquote>
    <h3>Minimalistic fashion <span>Lovely clothes</span></h3>
  </div>
  </div>
  <div class="col-md-4 text-center">
  <div class="profile">
    <img src="http://ipic.su/img/img7/fs/7B260436-ADEE-4E05-A17F-87B3DDFD5887.1614343801.jpg" class="user" >
    <blockquote>
      In our New Year story, we wanted to tell first of all about the family warmth and magic of a festive night. We created this atmosphere with the help of light, color and textures that we borrowed from canvases in the Rococo style, with their grace, intimacy, exquisite decorativeness and complex muted shades. The New Year gives us soulful and dear moments of meeting with loved ones. Their smiles and hugs that we missed so much.
    </blockquote>
    <h3>Gold earrings <span>Lovely clothes</span></h3>
  </div>
  </div>

<div class="col-md-4 text-center">
  <div class="profile">
    <img src="http://ipic.su/img/img7/fs/F6A99674-72A8-40EB-8A7F-0B71DCA6EFF3.1614343830.jpg" class="user" >
    <blockquote>
     In our New Year story, we wanted to tell first of all about the family warmth and magic of a festive night. We created this atmosphere with the help of light, color and textures that we borrowed from canvases in the Rococo style, with their grace, intimacy, exquisite decorativeness and complex muted shades. The New Year gives us soulful and dear moments of meeting with loved ones. Their smiles and hugs that we missed so much.
    </blockquote>
    <h3>Sweater<span>Lovely clothes</span></h3>
  </div>
  </div>
</div>
</div>
</section>

<div class="container">
	 <h3>BRANDS WE WORK WITH</h3>
	 <img src="http://ipic.su/img/img7/fs/New.1614597582.jpg" class="img-fluid" alt="">
</div>


<!---9-->
<section id="testimonials">
	<div class="container">
  	<h1 class="title text-center">WHAT CLIENTS SAY?</h1>
		<div class="row">
		<div class="col-md-5 testimonials">
			<p>In our New Year story, we wanted to tell first of all about <br>the family warmth and magic of a festive night.</p>
			<img src="http://ipic.su/img/img7/fs/Beznazvaniya.1614746756.jpg" alt="">
			<p class="user-details"><b>Angelina</b><br>Co-fouder at xyz</p>
		</div>
		<div class="col-md-5 testimonials"><!--осы аркылы екеуын жанына ко	дым-->
			<p>In our New Year story, we wanted to tell first of all about <br>the family warmth and magic of a festive night.</p>
			<img src="http://ipic.su/img/img7/fs/item8.1614746733.jpg" alt="">
			<p class="user-details"><b>John Doe</b><br>Director at xyz</p>
		</div>
		</div>
	</div>
</section>


		                   <!---Footer------>
	<footer>
    <div id="footer_middle">
		  <div id="middle_content">
				<div class="row">
					<div class="col-md-4 ">
						<div id="magazine">
							<p>"Lovely Clothes" was founded in 2020.</p>
							<p>"Lovely Clothes"is a fashion brand, a team of professionals and a huge community of girls in love with fashion. Design studio "Lovely Clothes" is located in the very heart of Europe - Germany. The main idea of the brand is to offer dozens of new designs of clothes and accessories every week!</p>
							<p>	<div id="cont">
									<ul class="level-0">

							            <span class="lcount">8 pages</span>
													<li class="lpage"><a href="http://s349355.smrtp.ru/" title="Lovely Clothes">Lovely Clothes</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/index.html" title="Lovely Clothes">Lovely Clothes</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/newitems.html" title="New items">New items</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/Footwear.html" title="Footwear">Footwear</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/Accessories.html" title="Accessories">Accessories</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/Dresses.html" title="Dresses">Dresses</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/Inspire.html" title="Inspire">Inspire</a></li>
													<li class="lpage last-page"><a href="http://s349355.smrtp.ru/Contact.html" title="Contact">Contact</a></li>
													</ul>
								</div></p>
							</div>
				  </div>
							<div class="col-md-3 ">
									<div id="magazine">
									   <h3><span>About us</span></h3>
									       <ul>
									          <li><a>Our stores</a></li>
									          <li><a>Connect with us</a></li>
									          <li><a>Partnership</a></li>
									          <li><a>Return and exchange</a></li>
									          <li><a>Delivery</a></li>
									          <li><a>Gift certificates</a></li>
									       </ul>
						     </div>
								  </div>
							   <div class="col-md-3 ">
									  <div id="magazine">
									      <h3><span> Our brand </span></h3>
									       <ul>
									          <li><a>Overalls</a></li>
									          <li><a>Blouses & Tops</a></li>
									          <li><a>Pants & Jeans</a></li>
									          <li><a>Sweaters & Hoodies</a></li>
									       </ul>
												 <br>

													<div class="container text-center">
														<p>FIND US ON SOCIAL MEDIA</p>
														<div class="social-icons">
														<a href="#"><img src="http://ipic.su/img/img7/fs/instagram-new(1).1614867238.png" alt=""></a>
														<a href="#"><img src="http://ipic.su/img/img7/fs/telegram-app.1614866641.png" alt=""></a>
														<a href="#"><img src="http://ipic.su/img/img7/fs/whatsapp.1614866547.png" alt=""></a>
														<a href="#"><img src="http://ipic.su/img/img7/fs/facebook-new.1614866776.png" alt=""></a>
														</div>
												</div>
						      	</div>
							   </div>
          </div>
       </div>
			  <div class="footer-copyright text-center py-3">
					<p>&copy; Copyright 2020 Lovely clothes  All Rights Reserved.</p>
					<p>Powered by Kazahstan - Designed & Developed By Lyazzat and Shugyla.</p>
				</div>
			</div>
   </footer>


</body>
</html>
