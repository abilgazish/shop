<!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
	<title>basket</title>
 	<meta name="viewport" content="1170">
	<link rel="stylesheet" href="style.css">
 	 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
 	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
</head>
 <body>
                  <!---vigation------------>
<section id="nav-bar">
	<nav class="navbar navbar-expand-lg navbar-light ">
  <div class="container-fluid">
    <a class="navbar-brand" href="index (20.php">
			<img src="http://ipic.su/img/img7/fs/75CE17C7-16A0-4939-9065-498C45DD493C.1614173565.jpg">
	  </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
         <li class="nav-item"><a class="nav-link" href="index (2).php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="modellingcourse.php">Modelling course</a></li>
        <li class="nav-item"><a class="nav-link" href="giftcard.php">Gift-Cards</a></li>
        <li class="nav-item"><a class="nav-link" href="cart_main.php">basket</a></li>
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Clothes</a>
		     <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="Dresses.php">Dress</a></li>
            <li><a class="dropdown-item" href="Footwear.php">Footwear</a></li>
            <li><a class="dropdown-item" href="Accessories.php">Accessories</a></li>
         </ul>
        </li>
				<li class="nav-item"><a class="nav-link " href="Inspire.php">Inspire</a></li>
        <li class="nav-item"><a class="nav-link" href="Contact.php">Contact</a></li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
  </nav>
</section>


	<?php 
     include("header.php");


	 ?>

	 <div class="container">
	 	<div class="col-md-12 get_cart my-5">
	 		
	 	</div>
	 </div>


	 <script type="text/javascript">
	 	$(document).ready(function(){
            
            show_mycart();
           function show_mycart(){
              $.ajax({
              url: "ajax/show_mycart.php",
              method:"POST",
              dataType:"JSON",
              success:function(data){
              	$("#get_cart").html(data.out);
                $("#cart").text(data.da);
                $("#total").text(data.total);
              }
           });
           }

           setInterval(show_mycart,1000);

	 	});

	 	$(document).on("click",".remove",function(){
             var id = $(this).attr("id");

             var action = "delete";

              $.ajax({
              url: "ajax/cart_action.php",
              method:"POST",
              data:{id:id,action:action},
              dataType:"JSON",
              success:function(data){
              
              }
           });
	 	});

	 		$(document).on("click",".clearall",function(){
             var id = $(this).attr("id");

             var action = "clearall";

              $.ajax({
              url: "ajax/cart_action.php",
              method:"POST",
              data:{id:id,action:action},
              dataType:"JSON",
              success:function(data){
              
              }
           });
	 	});
	 </script>

</body>
</html>