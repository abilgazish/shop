<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Footwear</title>
	<meta name="viewport" content="1170">
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<!---Navigation----->
<section id="nav-bar">
	<nav class="navbar navbar-expand-lg navbar-light ">
  <div class="container-fluid">
    <a class="navbar-brand" href="index (20.php">
			<img src="http://ipic.su/img/img7/fs/75CE17C7-16A0-4939-9065-498C45DD493C.1614173565.jpg">
	  </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
         <li class="nav-item"><a class="nav-link" href="index (2).php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="modellingcourse.php">Modelling course</a></li>
        <li class="nav-item"><a class="nav-link" href="giftcard.php">Gift-Cards</a></li>
        <li class="nav-item"><a class="nav-link" href="cart_main.php">basket</a></li>
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Clothes</a>
		     <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="Dresses.php">Dress</a></li>
            <li><a class="dropdown-item" href="Footwear.php">Footwear</a></li>
            <li><a class="dropdown-item" href="Accessories.php">Accessories</a></li>
         </ul>
        </li>
				<li class="nav-item"><a class="nav-link " href="Inspire.php">Inspire</a></li>
        <li class="nav-item"><a class="nav-link" href="Contact.php">Contact</a></li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
  </nav>
</section>
                 <!-- Actual accessories -->
       <section id="actual">
      	<div class="container">
       <h3>Footwear</h3>
       <div class="row">
       <div class="col-md-3 profile-pic text-center">
<div class="img-box">
	<img src="http://ipic.su/img/img7/fs/3D451DF3-A2C3-4F88-89C4-A51275988DD3.1614334120.jpg" class="img-responsive">
                   	 	</div>
                   	 	<h4>Fashionable boots autumn-winter</h4>
                   	 	<h5>50$</h5>
                   	 </div>
                   	 <div class="col-md-3 profile-pic text-center">
<div class="img-box">
	<img src="http://ipic.su/img/img7/fs/A8DBEE59-E61C-4B6A-B7EB-17C87AA211B6.1614334251.jpg" class="img-responsive">
                   	 	</div>
                   	 	<h4>Fashion sandals</h4>
                   	 	<h5>44$</h5>
                   	 </div>
                   	 <div class="col-md-3 profile-pic text-center">
<div class="img-box">
	<img src="http://ipic.su/img/img7/fs/B473B759-A0F7-48AB-9BD5-1828AEBB9F4A.1614334193.jpg" class="img-responsive">
                   	 	</div>
                   	 	<h4>White shoes</h4>
                   	 	<h5>54$</h5>
                   	 </div>
                   	 	 <div class="col-md-3 profile-pic text-center">
<div class="img-box">
	<img src="http://ipic.su/img/img7/fs/B7C09A45-814C-42A8-AA1C-16DB45B580AA.1614334225.jpg" class="img-responsive">
                   	 	</div>
                   	 	<h4>White sandals</h4>
                   	 	<h5>48$</h5>
                   	 </div>
                  	</div>
                   </div>
                   	 </section>



                        <section id="actual">
        <div class="container">
       <div class="row">
       <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/8B699156-DC25-4BF1-AAC2-E80830243475.1614334271.jpg" class="img-responsive">
                      </div>
                      <h4>Fashionable sneakers in a belt</h4>
                      <h5>52$</h5>
                     </div>
                     <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/9CD51548-3875-49A2-8B3C-2EA3BA888F64.1614334295.jpg" class="img-responsive">
                      </div>
                      <h4>Basic white sneakers</h4>
                      <h5>30$</h5>
                     </div>
                     <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/C6AB52AF-73A9-427B-8012-13B38F8B1C0F.1614334318.jpg" class="img-responsive">
                      </div>
                      <h4>Basic white sandals</h4>
                      <h5>20$</h5>
                     </div>
                       <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/09306CC9-6A8F-4017-A066-2B7C2C0DF495.1614334348.jpg" class="img-responsive">
                      </div>
                      <h4>Fashion sneakers 2021</h4>
                      <h5>41$</h5>
                     </div>
                    </div>
                   </div>
                     </section>




                          <section id="actual">
        <div class="container">
       <div class="row">
       <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/D595CD2D-1F97-42C1-A485-4D624C533769.1614335216.jpg" class="img-responsive">
                      </div>
                      <h4>Boots with huge soles</h4>
                      <h5>51$</h5>
                     </div>
                     <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/58695667-753D-4C5A-9203-10DF842E5CC2.1614335246.jpg" class="img-responsive">
                      </div>
                      <h4>Burgundy boots</h4>
                      <h5>42$</h5>
                     </div>
                     <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/0E94BF4F-43E6-486A-AFE1-650E0D710704.1614335266.jpg" class="img-responsive">
                      </div>
                      <h4>Boots 2020</h4>
                      <h5>39$</h5>
                     </div>
                       <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/B49E55B4-875B-439C-8A1E-A35E9A72F2C5.1614335284.jpg" class="img-responsive">
                      </div>
                      <h4>Martins</h4>
                      <h5>40$</h5>
                     </div>
                    </div>
                   </div>
	<img src="http://ipic.su/img/img7/fs/101-1015156_com-wave-1-line-art.1614707956.png" class="bottom-img" alt="">
</section>


		                   <!---Footer------>
	<footer>
    <div id="footer_middle">
		  <div id="middle_content">
				<div class="row">
					<div class="col-md-4 ">
						<div id="magazine">
							<p>"Lovely Clothes" was founded in 2020.</p>
							<p>"Lovely Clothes"is a fashion brand, a team of professionals and a huge community of girls in love with fashion. Design studio "Lovely Clothes" is located in the very heart of Europe - Germany. The main idea of the brand is to offer dozens of new designs of clothes and accessories every week!</p>
							<p>	<div id="cont">
									<ul class="level-0">

													<span class="lcount">8 pages</span>
													<li class="lpage"><a href="http://s349355.smrtp.ru/" title="Lovely Clothes">Lovely Clothes</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/index.html" title="Lovely Clothes">Lovely Clothes</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/newitems.html" title="New items">New items</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/Footwear.html" title="Footwear">Footwear</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/Accessories.html" title="Accessories">Accessories</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/Dresses.html" title="Dresses">Dresses</a></li>
													<li class="lpage"><a href="http://s349355.smrtp.ru/Inspire.html" title="Inspire">Inspire</a></li>
													<li class="lpage last-page"><a href="http://s349355.smrtp.ru/Contact.html" title="Contact">Contact</a></li>
													</ul>

								</div></p>
           	</div>
				  </div>
							<div class="col-md-3 ">
									<div id="magazine">
									   <h3><span>About us</span></h3>
									       <ul>
									          <li><a>Our stores</a></li>
									          <li><a>Connect with us</a></li>
									          <li><a>Partnership</a></li>
									          <li><a>Return and exchange</a></li>
									          <li><a>Delivery</a></li>
									          <li><a>Gift certificates</a></li>
									       </ul>
						     </div>
								  </div>
							   <div class="col-md-3 ">
									  <div id="magazine">
									      <h3><span> Our brand </span></h3>
									       <ul>
									          <li><a>Overalls</a></li>
									          <li><a>Blouses & Tops</a></li>
									          <li><a>Pants & Jeans</a></li>
									          <li><a>Sweaters & Hoodies</a></li>
									       </ul>
												 <br>

													<div class="container text-center">
														<p>FIND US ON SOCIAL MEDIA</p>
														<div class="social-icons">
														<a href="#"><img src="http://ipic.su/img/img7/fs/instagram-new(1).1614867238.png" alt=""></a>
														<a href="#"><img src="http://ipic.su/img/img7/fs/telegram-app.1614866641.png" alt=""></a>
														<a href="#"><img src="http://ipic.su/img/img7/fs/whatsapp.1614866547.png" alt=""></a>
														<a href="#"><img src="http://ipic.su/img/img7/fs/facebook-new.1614866776.png" alt=""></a>
														</div>
												</div>
						      	</div>
							   </div>
          </div>
       </div>
			  <div class="footer-copyright text-center py-3">
					<p>&copy; Copyright 2020 Lovely clothes  All Rights Reserved.</p>
					<p>Powered by Kazahstan - Designed & Developed By Lyazzat and Shugyla.</p>
				</div>
			</div>
   </footer>


</body>
</html>
