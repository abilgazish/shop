
      <!-- Video -->
<section>
    <video id="slider" autoplay loop muted>
      <source src="videoss/plm.mp4" type='video/mp4; codecs="avc1.42E01E, mp4a.40.2"'>
    </video>
   </section>
<!-- Video -->
    

<!-- Service Section -->
  <section id="serces">
    <div class="serces container">
      <div class="serce-top">
        <h1 class="section-title">WELCOME TO THE MODELLING COURSE</h1>
        <p>The work of "dreams" and pleasure for some girls is often the work of a model. Every pretty girl was told at least once: "you look like a model!" or "you definitely need to be a model!" Thinking about this profession, the catwalk, spotlights, magazine covers, money and luxury immediately appear. In the modern world of information availability, there are already fewer stereotypes that if you have a pretty face and not overweight figure, then you can work in this area.</p>
      </div>
      <div class="serce-bottom">
        <div class="serce-item">
    
          <h2>FirstProgram</h2>
          <p>Catwalk step, photo posing, style, make up, acting
The basics of professional camera work
- How to be relaxed and confident
in yourself at shooting, castings and in life
- Working with the face. Mimicry, emotions
- Posing for Fashion Shooting.
Correct presentation of the image, clothing,
accessories, work for advertising</p>
        </div>
        <div class="serce-item">
       
          <h2>SecondProgram</h2>
          <p>Portfolio creation
Photoshoot Model tests
Basic photography for portfolio
models, in black and white style.
Stylist and hairdresser work included (clothing provided)
6-12 photos</p>
        </div>
        <div class="serce-item">

          <h2>ThirdProgram</h2>
          <p>10 individual castings
to Russian and foreign
modeling agencies
After the course we will arrange for you
individual castings for the presenters
model agencies of Russia,
to our foreign partners,
and also tell you where to look
commercial shooting, if you have
non-standard appearance</p>
        </div>
        <div class="serce-item">
     
          <h2>FourthProgram</h2>
          <p>Self-confidence trainings
We will show you how you can use clothes
hide flaws and emphasize
dignity of the figure, together we will find
your individual styleLorem ipsum dolor sit amet consectetur adipisicing elit. Corporis debitis rerum, magni voluptatem sed architecto placeat beatae tenetur officia quod</p>
        </div>
      </div>
    </div>
  </section>
  <!-- End Service Section -->

  <div class="galleries-2">
          <div id="slider-wrap">
              <div class="video">
                <iframe width="100%" height="250" src="https://youtube.com/embed/z9dqTAYpqN4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
              <div class="video">
                <iframe width="100%" height="250" src="https://www.youtube.com/embed/UPWlElg2Qis" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
              <div class="video">
                <iframe width="100%" height="250" src="https://www.youtube.com/embed/rWaj-XtIkZ8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>      
        </div>

		                   <!---Footer------>
	<footer>
    <div id="footer_middle">
		  <div id="middle_content">
				<div class="row">
					<div class="col-md-4 ">
						<div id="magazine">
							<p>"Lovely Clothes" was founded in 2020.</p>
							<p>"Lovely Clothes"is a fashion brand, a team of professionals and a huge community of girls in love with fashion. Design studio "Lovely Clothes" is located in the very heart of Europe - Germany. The main idea of the brand is to offer dozens of new designs of clothes and accessories every week!</p>
              <p>
                <div id="cont">
									<ul class="level-0">
							            <span class="lcount">8 pages</span>
                          <li class="lpage"><a href="http://s349355.smrtp.ru/" title="Lovely Clothes">Lovely Clothes</a></li>
                          <li class="lpage"><a href="http://s349355.smrtp.ru/index.html" title="Lovely Clothes">Lovely Clothes</a></li>
                          <li class="lpage"><a href="http://s349355.smrtp.ru/newitems.html" title="New items">New items</a></li>
                          <li class="lpage"><a href="http://s349355.smrtp.ru/Footwear.html" title="Footwear">Footwear</a></li>
                          <li class="lpage"><a href="http://s349355.smrtp.ru/Accessories.html" title="Accessories">Accessories</a></li>
                          <li class="lpage"><a href="http://s349355.smrtp.ru/Dresses.html" title="Dresses">Dresses</a></li>
                          <li class="lpage"><a href="http://s349355.smrtp.ru/Inspire.html" title="Inspire">Inspire</a></li>
                          <li class="lpage last-page"><a href="http://s349355.smrtp.ru/Contact.html" title="Contact">Contact</a></li>
                          </ul>

								</div></p>
           	</div>
				  </div>
							<div class="col-md-3 ">
									<div id="magazine">
									   <h3><span>About us</span></h3>
									       <ul>
									          <li><a>Our stores</a></li>
									          <li><a>Connect with us</a></li>
									          <li><a>Partnership</a></li>
									          <li><a>Return and exchange</a></li>
									          <li><a>Delivery</a></li>
									          <li><a>Gift certificates</a></li>
									       </ul>
						     </div>
								  </div>
							   <div class="col-md-3 ">
									  <div id="magazine">
									      <h3><span> Our brand </span></h3>
									       <ul>
									          <li><a>Overalls</a></li>
									          <li><a>Blouses & Tops</a></li>
									          <li><a>Pants & Jeans</a></li>
									          <li><a>Sweaters & Hoodies</a></li>
									       </ul>
												 <br>

													<div class="container text-center">
														<p>FIND US ON SOCIAL MEDIA</p>
														<div class="social-icons">
														<a href="#"><img src="http://ipic.su/img/img7/fs/instagram-new(1).1614867238.png" alt=""></a>
														<a href="#"><img src="http://ipic.su/img/img7/fs/telegram-app.1614866641.png" alt=""></a>
														<a href="#"><img src="http://ipic.su/img/img7/fs/whatsapp.1614866547.png" alt=""></a>
														<a href="#"><img src="http://ipic.su/img/img7/fs/facebook-new.1614866776.png" alt=""></a>
														</div>
												</div>
						      	</div>
							   </div>
          </div>
       </div>
			  <div class="footer-copyright text-center py-3">
					<p>&copy; Copyright 2020 Lovely clothes  All Rights Reserved.</p>
					<p>Powered by Kazahstan - Designed & Developed By Lyazzat and Shugyla.</p>
				</div>
			</div>
   </footer>


   </body>
   </html>
