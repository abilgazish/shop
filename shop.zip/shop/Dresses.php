<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dresses</title>
	<meta name="viewport" content="1170">
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
                   <!---Navigation----->
<section id="nav-bar">
	<nav class="navbar navbar-expand-lg navbar-light ">
  <div class="container-fluid">
    <a class="navbar-brand" href="index (20.php">
			<img src="http://ipic.su/img/img7/fs/75CE17C7-16A0-4939-9065-498C45DD493C.1614173565.jpg">
	  </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
         <li class="nav-item"><a class="nav-link" href="index (2).php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="modellingcourse.php">Modelling course</a></li>
        <li class="nav-item"><a class="nav-link" href="giftcard.php">Gift-Cards</a></li>
        <li class="nav-item"><a class="nav-link" href="cart_main.php">basket</a></li>
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Clothes</a>
		     <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="Dresses.php">Dress</a></li>
            <li><a class="dropdown-item" href="Footwear.php">Footwear</a></li>
            <li><a class="dropdown-item" href="Accessories.php">Accessories</a></li>
         </ul>
        </li>
				<li class="nav-item"><a class="nav-link " href="Inspire.php">Inspire</a></li>
        <li class="nav-item"><a class="nav-link" href="Contact.php">Contact</a></li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
  </nav>
</section>

                 <!-- Actual accessories -->
       <section id="actual">
      	<div class="container">
       <h3>Dresses</h3>
       <div class="row">
       <div class="col-md-3 profile-pic text-center">
<div class="img-box">
	<img src="http://ipic.su/img/img7/fs/2477E448-8BF6-4777-9A2C-A83B85981C83.1614404939.jpg" class="img-responsive">
                   	 	</div>
                   	 	<h4>Satin Dress</h4>
                   	 	<h5>43$</h5>
                   	 </div>
                   	 <div class="col-md-3 profile-pic text-center">
<div class="img-box">
	<img src="http://ipic.su/img/img7/fs/7343C202-5827-4DBD-93FC-8ED634448A43.1614405060.jpg" class="img-responsive">
                   	 	</div>
                   	 	<h4>Blue long dress</h4>
                   	 	<h5>40$</h5>
                   	 </div>
                   	 <div class="col-md-3 profile-pic text-center">
<div class="img-box">
	<img src="http://ipic.su/img/img7/fs/A0EA027F-A2C4-47B1-8142-538CB4491D20.1614405081.jpg" class="img-responsive">
                   	 	</div>
                   	 	<h4>White pretty dress</h4>
                   	 	<h5>38$</h5>
                   	 </div>
                   	 	 <div class="col-md-3 profile-pic text-center">
<div class="img-box">
	<img src="http://ipic.su/img/img7/fs/7541CB5C-E17A-4919-9131-1F1FA34843CD.1614405105.jpg" class="img-responsive">
                   	 	</div>
                   	 	<h4>Dresses in a belt</h4>
                   	 	<h5>35$</h5>
                   	 </div>
                  	</div>
                   </div>
                   	 </section>



                        <section id="actual">
        <div class="container">
       <div class="row">
       <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/F90EB554-905E-4C51-9CE6-13F623ABAFA6.1614405126.jpg" class="img-responsive">
                      </div>
                      <h4>Blue pretty dress</h4>
                      <h5>52$</h5>
                     </div>
                     <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/B85ABF7B-F6ED-40A9-8F33-C4C8E30BFE90.1614405150.jpg" class="img-responsive">
                      </div>
                      <h4>Green dress</h4>
                      <h5>50$</h5>
                     </div>
                     <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/80C42D99-700A-44F2-B1A6-92D975D714BA.1614405173.jpg" class="img-responsive">
                      </div>
                      <h4>Dresses blazer</h4>
                      <h5>39$</h5>
                     </div>
                       <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/24A61B04-A616-4CD3-B625-F6C7F66A11EC.1614405194.jpg" class="img-responsive">
                      </div>
                      <h4>Milk dress 2021</h4>
                      <h5>41$</h5>
                     </div>
                    </div>
                   </div>
                     </section>




                          <section id="actual">
        <div class="container">
       <div class="row">
       <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/21DEE8AD-4AC8-418C-ADB0-0ADF8205D62B.1614405222.jpg" class="img-responsive">
                      </div>
                      <h4>Blue lond dress</h4>
                      <h5>51$</h5>
                     </div>
                     <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/59CFA009-E0AD-45CF-8BF9-A42093F2B594.1614405255.jpg" class="img-responsive">
                      </div>
                      <h4>Green dress blazer</h4>
                      <h5>42$</h5>
                     </div>
                     <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/398B593A-E9D4-43FD-B998-928457996746.1614405275.jpg" class="img-responsive">
                      </div>
                      <h4>Evening dresses</h4>
                      <h5>39$</h5>
                     </div>
                       <div class="col-md-3 profile-pic text-center">
<div class="img-box">
  <img src="http://ipic.su/img/img7/fs/96D38642-842D-4919-ABE7-381CE74B57F8.1614405294.jpg" class="img-responsive">
                      </div>
                      <h4>Dress blazer</h4>
                      <h5>40$</h5>
                     </div>
                    </div>
                   </div>

									 <img src="http://ipic.su/img/img7/fs/101-1015156_com-wave-1-line-art.1614707956.png" class="bottom-img" alt="">
									                      </section>



																						                   <!---Footer------>
																					<footer>
																				    <div id="footer_middle">
																						  <div id="middle_content">
																								<div class="row">
																									<div class="col-md-4 ">
																										<div id="magazine">
																											<p>"Lovely Clothes" was founded in 2020.</p>
																											<p>"Lovely Clothes"is a fashion brand, a team of professionals and a huge community of girls in love with fashion. Design studio "Lovely Clothes" is located in the very heart of Europe - Germany. The main idea of the brand is to offer dozens of new designs of clothes and accessories every week!</p>
																											<p>	<div id="cont">
																													<ul class="level-0">

																											            <span class="lcount">8 pages</span>
																																	<li class="lpage"><a href="http://s349355.smrtp.ru/" title="Lovely Clothes">Lovely Clothes</a></li>
																																	<li class="lpage"><a href="http://s349355.smrtp.ru/index.html" title="Lovely Clothes">Lovely Clothes</a></li>
																																	<li class="lpage"><a href="http://s349355.smrtp.ru/newitems.html" title="New items">New items</a></li>
																																	<li class="lpage"><a href="http://s349355.smrtp.ru/Footwear.html" title="Footwear">Footwear</a></li>
																																	<li class="lpage"><a href="http://s349355.smrtp.ru/Accessories.html" title="Accessories">Accessories</a></li>
																																	<li class="lpage"><a href="http://s349355.smrtp.ru/Dresses.html" title="Dresses">Dresses</a></li>
																																	<li class="lpage"><a href="http://s349355.smrtp.ru/Inspire.html" title="Inspire">Inspire</a></li>
																																	<li class="lpage last-page"><a href="http://s349355.smrtp.ru/Contact.html" title="Contact">Contact</a></li>
																																	</ul>

																												</div></p>
																				           	</div>
																								  </div>
																											<div class="col-md-3 ">
																													<div id="magazine">
																													   <h3><span>About us</span></h3>
																													       <ul>
																													          <li><a>Our stores</a></li>
																													          <li><a>Connect with us</a></li>
																													          <li><a>Partnership</a></li>
																													          <li><a>Return and exchange</a></li>
																													          <li><a>Delivery</a></li>
																													          <li><a>Gift certificates</a></li>
																													       </ul>
																										     </div>
																												  </div>
																											   <div class="col-md-3 ">
																													  <div id="magazine">
																													      <h3><span> Our brand </span></h3>
																													       <ul>
																													          <li><a>Overalls</a></li>
																													          <li><a>Blouses & Tops</a></li>
																													          <li><a>Pants & Jeans</a></li>
																													          <li><a>Sweaters & Hoodies</a></li>
																													       </ul>
																																 <br>

																																	<div class="container text-center">
																																		<p>FIND US ON SOCIAL MEDIA</p>
																																		<div class="social-icons">
																																		<a href="#"><img src="http://ipic.su/img/img7/fs/instagram-new(1).1614867238.png" alt=""></a>
																																		<a href="#"><img src="http://ipic.su/img/img7/fs/telegram-app.1614866641.png" alt=""></a>
																																		<a href="#"><img src="http://ipic.su/img/img7/fs/whatsapp.1614866547.png" alt=""></a>
																																		<a href="#"><img src="http://ipic.su/img/img7/fs/facebook-new.1614866776.png" alt=""></a>
																																		</div>
																																</div>
																										      	</div>
																											   </div>
																				          </div>
																				       </div>
																							  <div class="footer-copyright text-center py-3">
																									<p>&copy; Copyright 2020 Lovely clothes  All Rights Reserved.</p>
																									<p>Powered by Kazahstan - Designed & Developed By Lyazzat and Shugyla.</p>
																								</div>
																							</div>
																				   </footer>


</body>
</html>
